package biblioteca.biblioteca;


public class Livros extends javax.swing.JFrame{
        
	public String titulo;
	private int codLivro;
	
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getCodLivro() {
		return codLivro;
	}

	public void setCodLivro(int codLivro) {
		this.codLivro = codLivro;
	}
    }
